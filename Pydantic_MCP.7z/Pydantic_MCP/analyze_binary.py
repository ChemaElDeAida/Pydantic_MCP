import asyncio
from pydantic_ai import Agent
import mcp_client
from pydantic_ai.models.gemini import GeminiModel
from pydantic_ai.providers.google_gla import GoogleGLAProvider
from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.providers.anthropic import AnthropicProvider
from pydantic_ai.models.openai import OpenAIModel
from pydantic_ai.providers.openai import OpenAIProvider

# Configuración de modelos: añade aquí más modelos fácilmente
MODEL_CONFIGS = [
    {
        'name': 'Gemini',
        'model_class': GeminiModel,
        'provider': GoogleGLAProvider(api_key='AIzaSyAYXNByPMyooQTZDig21a088vAus0bnV0I'),
        'model_args': {'model_name': 'gemini-2.0-flash'},
    },
    {
        'name': 'qwen3',
        'model_class': OpenAIModel,
        'provider': OpenAIProvider(base_url='http://localhost:11434/v1'),
        'model_args': {'model_name': 'qwen3:latest'},
    },
    {
        'name': 'huihui_ai',
        'model_class': OpenAIModel,
        'provider': OpenAIProvider(base_url='http://localhost:11434/v1'),
        'model_args': {'model_name': 'huihui_ai/foundation-sec-abliterated:latest'},
    },

     = OpenAIModel(
        'anthropic/claude-3.5-sonnet',
        provider=OpenRouterProvider(api_key='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'),
    )
    agent = Agent(model)
    # Ejemplo para añadir Claude/Anthropic:
    # {
    #     'name': 'Claude',
    #     'model_class': AnthropicModel,
    #     'provider': AnthropicProvider(api_key='TU_API_KEY'),
    #     'model_args': {'model_name': 'claude-3-opus-20240229'},
    # },
]

async def analyze_binary():
    try:
        client = mcp_client.MCPClient()
        client.load_servers("GhidraMCP.json")
        tools = await client.start()

        # Inicializa todos los agentes según la configuración
        agents = []
        for config in MODEL_CONFIGS:
            model = config['model_class'](
                **config['model_args'], provider=config['provider']
            )
            agent = Agent(
                model, tools=tools,
                context="You are a security expert. You will be given a binary file and you need to analyze it using the MCP tools. Please answer in one sentence and take all the time you need."
            )
            agents.append({'name': config['name'], 'agent': agent})

        print("Agents initialized successfully.")

        questions = [
            "Can you identify the password to solve the binary, use the GhidraMCP tools?.",
            "Can you list the functions?",
            "Can you identify the main function?"
        ]

        # Aquí puedes añadir lógica para preguntas específicas según el tipo de binario
        # Por ejemplo:
        # if "crackme" in binary_path.lower():
        #     questions.append(...)
        # elif "malware" in binary_path.lower():
        #     questions.append(...)

        for question in questions:
            print(f"[You]: {question}")
            results = []
            for entry in agents:
                result = await entry['agent'].run(question)
                print(f"[{entry['name']}]: {result.output}\n")
                results.append((entry['name'], result.output))
            # Guarda resultados en el archivo
            with open("analysis_results.txt", "a", encoding="utf-8") as file:
                file.write(f"[You]: {question}\n")
                for name, output in results:
                    file.write(f"[{name}]: {output}\n")
                file.write("\n")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(analyze_binary())