#!/bin/sh
acr -p
