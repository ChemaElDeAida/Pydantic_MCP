from agno.agent import Agent, RunResponse
from agno.models.ollama import Ollama
from agno.models.google import Gemini
from agno.tools.mcp import MCPTools
import asyncio


async with MCPTools(command=f"python C:\\Users\\Alber\\Desktop\\TFM\\bridge_mcp_ghidra.py --ghidra-server http://127.0.0.1:8080/") as mcp_ghidra:


    #agent = Agent(
    #    model=Ollama(id="llama3.1"),
    ##   markdown=True,
    #   debug_mode=True
    #)
    agent = Agent(
        model=Gemini(id="gemini-2.0-flash", search=True, api_key="AIzaSyAYXNByPMyooQTZDig21a088vAus0bnV0I", tools=[mcp_ghidra]),
        show_tool_calls=True,
        markdown=True,
    
    )

    await agent.aprint_response("Tell me all the Ghidra tools you have available")

