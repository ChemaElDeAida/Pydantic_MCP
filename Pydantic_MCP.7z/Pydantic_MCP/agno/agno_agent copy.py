import asyncio
from pathlib import Path
from textwrap import dedent

from agno.agent import Agent
from agno.models.google import Gemini
from agno.tools.mcp import MCPTools, SSEClientParams


sse_params = SSEClientParams(
        url="http://localhost:8081/sse",
        timeout=600,  # 10 minutes for connection timeout
        sse_read_timeout=1800  # 30 minutes for read timeout
    )




async def run_agent(message: str) -> None:
    """Run the MCPTools with the given message."""

    
    async with MCPTools(server_params=sse_params, transport="sse", timeout_seconds=300) as mcp_ghidra:
        agent = Agent(
            model=Gemini(id="gemini-2.0-flash", search=True, api_key='AIzaSyAYXNByPMyooQTZDig21a088vAus0bnV0I'),
            tools=[mcp_ghidra],
            instructions=dedent("""\
                You are an expert in reverse engeniering, and you have access to both the binaries opened in Ghidra and the tools provided by the Ghidra MCP server.
                                You will use the tools provided to analyze a binary file.
                                You will be precise and concise in your answers.
                                You will explain the steps you take to analyze the binary.\
            """),
            markdown=True,
            show_tool_calls=True,
            debug_mode=True
        )

        # Run the agent
        await agent.aprint_response(message, stream=True)


# Example usage
if __name__ == "__main__":
    # Basic example - exploring project license
    asyncio.run(run_agent("Using the tools provided by the Ghidra MCP Server, name me all the Functions in the binary file opened in Ghidra."))

