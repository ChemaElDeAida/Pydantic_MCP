from agno.agent import Agent, RunResponse
from agno.models.ollama import Ollama
from agno.models.google import Gemini
from agno.tools.mcp import MCPTools
from agno.tools.reasoning import ReasoningTools
from textwrap import dedent
from mcp import StdioServerParameters


async def main():

    async with MCPTools("python bridge_mcp_ghidra.py --ghidra-server http://127.0.0.1:8080/") as mcp_ghidra:
    
    #agent = Agent(
    #    model=Ollama(id="llama3.1"),
    ##   markdown=True,
    #   debug_mode=True
    #)
        agent = Agent(
        model=Gemini(id="gemini-2.0-flash", search=True, api_key="AIzaSyAYXNByPMyooQTZDig21a088vAus0bnV0I"),
        tools=[mcp_ghidra, ReasoningTools(add_instructions=True)],
        instructions=dedent("""\
                You are an expert in reverse engeniering, and you have access to both the binaries opened in Ghidra and the tools provided by the Ghidra MCP server.
                                You will use the tools provided to analyze a binary file.
                                You will be precise and concise in your answers.
                                You will explain the steps you take to analyze the binary.\
            """),
        show_tool_calls=True,
        markdown=True,
        debug_mode=True
    
    )

    await agent.aprint_response("Tell me all the Ghidra tools you have available from the MCP server, and use them to list the functions in the binary file opened in Ghidra, Ghidra server is running on localhost:8080.", stream=True)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())